# coding-project-template
This repo is for the practice project which is to be based on Embedded AI libraries. 
